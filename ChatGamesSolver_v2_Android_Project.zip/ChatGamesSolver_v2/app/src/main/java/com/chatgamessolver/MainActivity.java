package com.chatgamessolver;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Bitmap;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.media.projection.MediaProjection;
import android.media.Image;
import android.media.ImageReader;
import android.hardware.display.VirtualDisplay;
import android.hardware.display.DisplayManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.Gravity;
import android.widget.*;
import android.graphics.ImageFormat;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.nio.ByteBuffer;
import java.util.regex.*;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 77;
    private TextView status, question, answer;
    private Button startButton, stopButton;
    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay display;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false, processing = false;
    private String lastQuestion = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("ChatGames Solver"); title.setTextSize(28);
        title.setGravity(Gravity.CENTER); root.addView(title);

        TextView note = new TextView(this);
        note.setText("Minecraft Bedrock में सवाल दिखाएँ। स्क्रीन पढ़ने की अनुमति Android खुद माँगेगा।");
        note.setTextSize(16); note.setPadding(0, 18, 0, 18); root.addView(note);

        startButton = new Button(this);
        startButton.setText("स्क्रीन पढ़ना शुरू करें"); root.addView(startButton);
        stopButton = new Button(this);
        stopButton.setText("बंद करो"); stopButton.setEnabled(false); root.addView(stopButton);

        status = new TextView(this);
        status.setText("स्थिति: बंद"); status.setTextSize(16);
        status.setPadding(0, 22, 0, 8); root.addView(status);

        TextView qLabel = new TextView(this);
        qLabel.setText("पहचाना गया सवाल"); qLabel.setTextSize(16); root.addView(qLabel);
        question = new TextView(this);
        question.setText("—"); question.setTextSize(20);
        question.setPadding(0, 6, 0, 16); root.addView(question);

        TextView aLabel = new TextView(this);
        aLabel.setText("जवाब"); aLabel.setTextSize(18); root.addView(aLabel);
        answer = new TextView(this);
        answer.setText("—"); answer.setTextSize(34);
        answer.setGravity(Gravity.CENTER); root.addView(answer);

        setContentView(root);
        startButton.setOnClickListener(v -> {
            MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
        });
        stopButton.setOnClickListener(v -> stopCapture());
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
                projection = manager.getMediaProjection(resultCode, data);
                startCapture();
            } else status.setText("स्थिति: अनुमति नहीं मिली");
        }
    }

    private void startCapture() {
        if (projection == null) return;
        DisplayMetrics metrics = new DisplayMetrics();
        ((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(metrics);
        reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, ImageFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("ChatGamesCapture", metrics.widthPixels, metrics.heightPixels,
            metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        running = true; processing = false;
        startButton.setEnabled(false); stopButton.setEnabled(true);
        status.setText("स्थिति: स्क्रीन पढ़ रहा है — अब Minecraft पर जाएँ");
        handler.post(captureLoop);
    }

    private final Runnable captureLoop = new Runnable() {
        @Override public void run() {
            if (!running || reader == null) return;
            if (!processing) {
                Image image = reader.acquireLatestImage();
                if (image != null) {
                    processing = true;
                    try {
                        Image.Plane plane = image.getPlanes()[0];
                        ByteBuffer buffer = plane.getBuffer();
                        int pixelStride = plane.getPixelStride();
                        int paddedWidth = plane.getRowStride() / pixelStride;
                        Bitmap bitmap = Bitmap.createBitmap(paddedWidth, image.getHeight(), Bitmap.Config.ARGB_8888);
                        buffer.rewind(); bitmap.copyPixelsFromBuffer(buffer);
                        Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, image.getWidth(), image.getHeight());
                        image.close();
                        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                            .process(InputImage.fromBitmap(cropped, 0))
                            .addOnSuccessListener(text -> {
                                String expr = findExpression(text.getText());
                                if (!expr.isEmpty() && !expr.equals(lastQuestion)) {
                                    lastQuestion = expr; question.setText(expr);
                                    answer.setText(solve(expr)); status.setText("स्थिति: सवाल मिल गया");
                                }
                            })
                            .addOnFailureListener(e -> status.setText("स्थिति: टेक्स्ट पढ़ने में समस्या"))
                            .addOnCompleteListener(task -> processing = false);
                    } catch (Exception e) {
                        image.close(); processing = false;
                    }
                }
            }
            if (running) handler.postDelayed(this, 1200);
        }
    };

    private String findExpression(String text) {
        String cleaned = text.replace("×", "x").replace("X", "x");
        Matcher m = Pattern.compile("(-?\\d{1,9})\\s*([+x*/÷-])\\s*(-?\\d{1,9})").matcher(cleaned);
        return m.find() ? m.group() : "";
    }

    private String solve(String expr) {
        Matcher m = Pattern.compile("(-?\\d+)\\s*([+x*/÷-])\\s*(-?\\d+)").matcher(expr);
        if (!m.find()) return "सवाल समझ नहीं आया";
        try {
            long a = Long.parseLong(m.group(1)), b = Long.parseLong(m.group(3)), r;
            switch (m.group(2)) {
                case "+": r = Math.addExact(a,b); break;
                case "-": r = Math.subtractExact(a,b); break;
                case "x": case "*": r = Math.multiplyExact(a,b); break;
                case "/": case "÷":
                    if (b == 0) return "शून्य से भाग नहीं";
                    if (a % b != 0) return String.valueOf((double)a / b);
                    r = a / b; break;
                default: return "ऑपरेटर नहीं पहचाना";
            }
            return String.valueOf(r);
        } catch (Exception e) { return "बड़ी संख्या / गलत सवाल"; }
    }

    private void stopCapture() {
        running = false; handler.removeCallbacks(captureLoop);
        if (display != null) { display.release(); display = null; }
        if (reader != null) { reader.close(); reader = null; }
        if (projection != null) { projection.stop(); projection = null; }
        if (startButton != null) startButton.setEnabled(true);
        if (stopButton != null) stopButton.setEnabled(false);
        if (status != null) status.setText("स्थिति: बंद");
    }

    @Override protected void onDestroy() { stopCapture(); super.onDestroy(); }
}
